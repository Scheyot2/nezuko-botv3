---
name: Bug Report
about: Create a report to help us
title: "[BUG]"
labels: bug
assignees: phaticusthiccy

---

**Describe the bug**
A clear and concise description of what the bug is.

**The server you use the module on**
Eg: Heroku, AWS, Railway, Local etc..

**Additional ınformation**
goes here <<
