clear 
npm -v 
sleep 1
clear 
npm install 
npm i -g
npm fund
npm audit fix
yarn install
npm test
